-- Updates media + owner communication fields.
-- Run this in Supabase SQL Editor. Safe to rerun.

alter table public.updates
add column if not exists horse_name text;

alter table public.updates
add column if not exists photo_urls text;

alter table public.updates
add column if not exists video_urls text;

alter table public.updates
add column if not exists link_urls text;

alter table public.updates
add column if not exists send_status text default 'Draft';

alter table public.updates
add column if not exists sent_at timestamptz;
