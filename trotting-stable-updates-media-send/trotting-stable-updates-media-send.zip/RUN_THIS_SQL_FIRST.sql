-- Owners, analytics, calendar and expense automation update.
-- Run this in Supabase SQL Editor before uploading the app code.

create table if not exists public.horse_owners (
  id uuid primary key default gen_random_uuid(),
  stable_id uuid references public.stables(id) on delete cascade,
  horse_name text not null,
  owner_name text not null,
  percentage numeric default 100,
  created_at timestamptz default now()
);

alter table public.horse_owners enable row level security;

drop policy if exists "Users can access horse owners in own stable" on public.horse_owners;
create policy "Users can access horse owners in own stable"
on public.horse_owners for all
using (stable_id in (select stable_id from public.profiles where id = auth.uid()))
with check (stable_id in (select stable_id from public.profiles where id = auth.uid()));

alter table public.horses add column if not exists owner_percentage numeric default 100;

alter table public.race_records add column if not exists prizemoney numeric default 0;
alter table public.race_records add column if not exists result text;
alter table public.race_records add column if not exists status text;

alter table public.treatments add column if not exists bill_amount numeric default 0;
alter table public.treatments add column if not exists bill_to_owners text default 'No';

alter table public.finance_entries add column if not exists bill_to_owners text default 'No';

alter table public.work_entries add column if not exists overall_time text;
alter table public.work_entries add column if not exists mile_rate text;
alter table public.work_entries add column if not exists last_half text;
alter table public.work_entries add column if not exists last_quarter text;
alter table public.work_entries add column if not exists recovery text;
alter table public.work_entries add column if not exists warmup text;
alter table public.work_entries add column if not exists sector text;
alter table public.work_entries add column if not exists distance text;
alter table public.work_entries add column if not exists driver text;
alter table public.work_entries add column if not exists notes text;

alter table public.invoices add column if not exists line_items jsonb default '[]'::jsonb;
alter table public.invoices add column if not exists client_phone text;
alter table public.invoices add column if not exists amount numeric default 0;
alter table public.invoices add column if not exists gst numeric default 0;
alter table public.invoices add column if not exists total numeric default 0;

-- Backfill horse_owners from existing horses primary owner where possible.
insert into public.horse_owners (stable_id, horse_name, owner_name, percentage)
select stable_id, name, owner, coalesce(owner_percentage, 100)
from public.horses
where owner is not null
and owner <> ''
and not exists (
  select 1 from public.horse_owners ho
  where ho.stable_id = horses.stable_id
  and ho.horse_name = horses.name
  and ho.owner_name = horses.owner
);
