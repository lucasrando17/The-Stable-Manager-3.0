-- Work section update: adds sectional columns used by the new Work panel.
-- Run this in Supabase SQL Editor before/after uploading. It is safe to rerun.

alter table public.work_entries
add column if not exists overall_time text;

alter table public.work_entries
add column if not exists mile_rate text;

alter table public.work_entries
add column if not exists last_half text;

alter table public.work_entries
add column if not exists last_quarter text;

alter table public.work_entries
add column if not exists recovery text;

alter table public.work_entries
add column if not exists warmup text;

alter table public.work_entries
add column if not exists sector text;

alter table public.work_entries
add column if not exists distance text;

alter table public.work_entries
add column if not exists driver text;

alter table public.work_entries
add column if not exists notes text;
